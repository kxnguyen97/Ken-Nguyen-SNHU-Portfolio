#include <iostream>
#include <iomanip>
#include "investment.h"
using namespace std;

int main() {

	double initialAmt, monthlyDep, interestRate;
	int years;

	cout << "=============================================\n";
	cout << "      Airgead Banking Investment Calculator\n";
	cout << "=============================================\n\n";

	cout << "Enter initial investment amount: ";
	cin >> initialAmt;
	while (initialAmt <= 0) {
		cout << "Please enter a positive value: ";
		cin >> initialAmt;
	}

	cout << "Enter monthly Deposit amount: ";
	cin >> monthlyDep;
	while (monthlyDep < 0) {
		cout << " Please enetr a non-negative value: ";
		cin >> monthlyDep;
	}

	cout << "Enter annual interest rate (percent): ";
	cin >> interestRate;
	while (interestRate <= 0) {
		cout << "Please eneter a positive value: ";
		cin >> interestRate;
	}

	cout << "Enter number of years: ";
	cin >> years;
	while (years <= 0) {
		cout << "Please enter a positive value: ";
		cin >> years;
	}

	Investment inv(initialAmt, monthlyDep, interestRate, years);
	 
	auto noDepResults = inv.calculateWithoutMonthlyDeposits();
	auto withDepResults = inv.calculateWithMonthlyDeposits();

	cout << "\n\n  Balance and Interest Without Additional Monthly Deposits\n";
	cout << "----------------------------------------------------------------\n";
	cout << "Year\tYear End Balance\tInterest Earned\n";

	for (auto& data : noDepResults) {
		cout << data.year << "\t$" << fixed << setprecision(2)
			<< data.yearEndBalance << "\t\t$" << data.interestEarned << endl;
	}

	cout << "\n\n  Balance and Interest With Additional Monthly Deposits \n";
	cout << "--------------------------------------------------------------\n";
	cout << "Year\tYear End Balance\tInterest Ear ed\n";

	for (auto& data : withDepResults) {
		cout << data.year << "\t$" << fixed << setprecision(2)
			<< data.yearEndBalance << "\t\t$" << data.interestEarned << endl;
	}

	cout << "\nPress ENTER to exit.";
		cin.ignore();
	    cin.get();

	return 0;
}