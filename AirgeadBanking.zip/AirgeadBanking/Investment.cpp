#include "Investment.h"
#include <cmath>

// Constuctor stores all user inputs
Investment::Investment(double initAmt, double monthlyDep, double interestRate, int numYears) {
	initialInvestment = initAmt;
	monthlyDeposit = monthlyDep;
	annualInterestRate = interestRate;
	years = numYears;
}

// Calculates yearly totals WITHOUT monthly deposits
vector<YearData> Investment::calculateWithoutMonthlyDeposits() {
	vector<YearData> results;
	double balance = initialInvestment;

	double monthlyRate = annualInterestRate / 100.0 / 12.0;

	for (int i = 1; i <= years; i++) {
		double interestEarned = 0.0;

		for (int m = 0; m < 12; m++) {
			double interest = balance * monthlyRate;
			interestEarned += interest;
			balance += interest;
		}

		YearData data;
		data.year = i;
		data.yearEndBalance = balance;
		data.interestEarned = interestEarned;

		results.push_back(data);
	}

	return results;
}

// Calculates yearly totals WITH monthly deposits
vector<YearData> Investment::calculateWithMonthlyDeposits() {
	vector<YearData> results;
	double balance = initialInvestment;

	double monthlyRate = annualInterestRate / 100.0 / 12.0;

	for (int i = 1; i <= years; i++) {
		double interestEarned = 0.0;

		for (int m = 0; m < 12; m++) {
			balance += monthlyDeposit;
			double interest = balance * monthlyRate;
			interestEarned += interest;
			balance += interest;
		}

		YearData data;
		data.year = i;
		data.yearEndBalance = balance;
		data.interestEarned = interestEarned;

		results.push_back(data);
	}

	return results;
}