#ifndef INVESTMENT_H
#define INVESTMENT_H

#include <vector>
using namespace std;

// Struct to store yearly results
struct YearData {
	int year;
	double yearEndBalance;
	double interestEarned;
};

class Investment {
private: 
	double initialInvestment;
	double monthlyDeposit;
	double annualInterestRate;
	int years;

public:
	// Constructor
	Investment(double initAmt, double monthlyDep, double interestRate, int numYears);

	// Calculates yearly totals without monthly deposits
	vector<YearData> calculateWithoutMonthlyDeposits();

	//Calculates yearly totals with monthly deposits
	vector<YearData> calculateWithMonthlyDeposits();
};

#endif // !INVESTMENT_H
